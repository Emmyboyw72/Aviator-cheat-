import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { auth } from '../../lib/firebase';
import { GoogleAuthProvider, signInWithPopup } from 'firebase/auth';

const ADMIN_EMAIL = "mgodswill306@gmail.com";

export function AdminLogin() {
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async () => {
    setLoading(true);
    setError('');
    
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      
      if (result.user.email === ADMIN_EMAIL) {
        navigate('/admin');
      } else {
        setError('Access denied. This account is not an administrator.');
      }
    } catch (err: any) {
      console.error(err);
      setError('Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-soft p-4">
      <div className="card w-full max-w-md p-8 md:p-12 text-center">
        <div className="brand flex justify-center mb-8">
          <span className="brand-mark">♛</span>
          <div className="text-left">
            <b>EMIRAL GLOBAL</b>
            <small>ADMIN LOGIN</small>
          </div>
        </div>

        <h1 className="text-2xl font-black text-dark mb-2">Administrator Login</h1>
        <p className="muted mb-8">Sign in to manage products, orders and website content.</p>

        {error && (
          <div className="notice error mb-6">
            {error}
          </div>
        )}

        <button 
          onClick={handleLogin}
          disabled={loading}
          className="btn green w-full py-4 text-base flex items-center justify-center gap-3"
        >
          {loading ? (
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
          ) : (
            <>
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" />
                <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
              </svg>
              Sign in with Google
            </>
          )}
        </button>
        
        <div className="mt-8 pt-8 border-t border-line">
          <Link to="/" className="text-xs font-black uppercase tracking-widest text-slate-400 hover:text-dark transition-colors">
            Back to Website
          </Link>
        </div>
      </div>
    </div>
  );
}
