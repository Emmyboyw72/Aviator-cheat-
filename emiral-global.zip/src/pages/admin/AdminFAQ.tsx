import React, { useEffect, useState } from 'react';
import { db } from '../../lib/firebase';
import { collection, getDocs, deleteDoc, doc, addDoc, serverTimestamp } from 'firebase/firestore';
import { useForm } from 'react-hook-form';
import { Plus, Trash2, Save } from 'lucide-react';

export function AdminFAQ() {
  const [faqs, setFaqs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { register, handleSubmit, reset } = useForm();

  const fetchFaqs = async () => {
    const snap = await getDocs(collection(db, 'faqs'));
    setFaqs(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    setLoading(false);
  };

  useEffect(() => { fetchFaqs(); }, []);

  const onSubmit = async (data: any) => {
    await addDoc(collection(db, 'faqs'), { ...data, created_at: serverTimestamp() });
    reset();
    fetchFaqs();
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Delete this FAQ?')) {
      await deleteDoc(doc(db, 'faqs', id));
      fetchFaqs();
    }
  };

  if (loading) return <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green mx-auto mt-20"></div>;

  return (
    <div className="space-y-10">
      <div className="admin-head">
        <h1 className="text-3xl font-black text-dark">FAQ Management</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        <form onSubmit={handleSubmit(onSubmit)} className="card space-y-4 h-fit">
          <h2 className="text-xl font-black text-dark mb-4">Add New FAQ</h2>
          <div>
            <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Question</label>
            <input {...register('question', { required: true })} className="input" />
          </div>
          <div>
            <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Answer</label>
            <textarea {...register('answer', { required: true })} className="input h-32" />
          </div>
          <button type="submit" className="btn green w-full py-4 flex items-center justify-center gap-2">
            <Plus size={18} /> Add FAQ
          </button>
        </form>

        <div className="space-y-4">
          {faqs.map((f) => (
            <div key={f.id} className="card relative group">
              <button onClick={() => handleDelete(f.id)} className="absolute top-4 right-4 text-slate-300 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity">
                <Trash2 size={16} />
              </button>
              <h3 className="font-black text-dark mb-2 pr-8">{f.question}</h3>
              <p className="text-muted text-sm leading-relaxed">{f.answer}</p>
            </div>
          ))}
          {faqs.length === 0 && <div className="empty">No FAQs yet.</div>}
        </div>
      </div>
    </div>
  );
}
