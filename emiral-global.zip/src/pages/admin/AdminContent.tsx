import React, { useEffect, useState } from 'react';
import { db, storage } from '../../lib/firebase';
import { doc, getDoc, setDoc, collection, getDocs, serverTimestamp } from 'firebase/firestore';
import { useForm } from 'react-hook-form';
import { Save, Loader2, Globe } from 'lucide-react';
import { ImageUpload } from '../../components/ImageUpload';

export function AdminContent() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState<string | null>(null);
  const { register, handleSubmit, setValue, watch } = useForm();
  
  const heroImage = watch('heroImage');
  const promoImage = watch('promoImage');
  const bodyImage1 = watch('bodyImage1');
  const bodyImage2 = watch('bodyImage2');
  const adVideoUrl = watch('adVideoUrl');

  useEffect(() => {
    async function fetchSettings() {
      const snap = await getDocs(collection(db, 'settings'));
      const settings: any = {};
      snap.forEach(d => {
        settings[d.id] = d.data().value;
      });
      Object.keys(settings).forEach(key => setValue(key, settings[key]));
      setLoading(false);
    }
    fetchSettings();
  }, [setValue]);

  const onSubmit = async (data: any) => {
    setSaving(true);
    try {
      for (const key of Object.keys(data)) {
        await setDoc(doc(db, 'settings', key), { value: data[key], updated_at: serverTimestamp() });
      }
      alert('Settings saved successfully!');
    } catch (err) {
      alert('Failed to save settings.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green mx-auto mt-20"></div>;

  return (
    <div className="space-y-10 max-w-5xl">
      <div className="admin-head">
        <div>
          <div className="eyebrow">CMS</div>
          <h1 className="text-3xl font-black text-dark">Website Content</h1>
          <p className="muted text-sm">Manage homepage text, media, contact details and payment instructions.</p>
        </div>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-8 pb-20">
        <section className="card space-y-6">
          <h2 className="text-xl font-black text-dark flex items-center gap-3">
             Announcement Banner
          </h2>
          <div className="grid grid-cols-1 gap-6">
            <div>
              <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Banner Text</label>
              <textarea {...register('promoBanner')} className="input" placeholder="e.g. Natural wellness • Trusted community • Nigeria" />
            </div>
          </div>
        </section>

        <section className="card space-y-6">
          <h2 className="text-xl font-black text-dark">Homepage Hero</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div>
                <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Hero Headline</label>
                <input {...register('heroTitle')} className="input" placeholder="NATURAL WELLNESS. ROOTED IN PURPOSE." />
              </div>
              <div>
                <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Hero Sub-headline</label>
                <textarea {...register('heroSubtitle')} className="input h-32" />
              </div>
            </div>
            <div>
              <ImageUpload 
                label="Hero Image"
                currentImage={heroImage}
                onUploadSuccess={(url) => setValue('heroImage', url)}
                onRemove={() => setValue('heroImage', '')}
                folder="settings"
              />
            </div>
          </div>
        </section>

        <section className="card space-y-6">
          <h2 className="text-xl font-black text-dark">Website Body & Ads</h2>
          <p className="muted text-sm">Upload images for the website body and video placeholders for advertisements.</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ImageUpload 
              label="Body Image 1 (Welcome Section)"
              currentImage={bodyImage1}
              onUploadSuccess={(url) => setValue('bodyImage1', url)}
              onRemove={() => setValue('bodyImage1', '')}
              folder="settings"
            />

            <ImageUpload 
              label="Body Image 2 (Community Section)"
              currentImage={bodyImage2}
              onUploadSuccess={(url) => setValue('bodyImage2', url)}
              onRemove={() => setValue('bodyImage2', '')}
              folder="settings"
            />
          </div>

          <div className="pt-6 border-t border-line">
            <h3 className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-4 block">Video Ad</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <ImageUpload 
                label="Upload Video Ad"
                currentImage={adVideoUrl ? undefined : undefined} // Not showing preview here for video
                onUploadSuccess={(url) => setValue('adVideoUrl', url)}
                folder="ads"
                accept="video/*"
              />
              <div className="aspect-video bg-dark rounded-xl flex items-center justify-center text-white/20 text-[10px] font-black uppercase tracking-widest border border-dark overflow-hidden">
                {adVideoUrl ? (
                  <video src={adVideoUrl} controls className="w-full h-full object-cover" />
                ) : (
                  <span>Video Preview</span>
                )}
              </div>
            </div>
          </div>
        </section>

        <section className="card space-y-6">
          <h2 className="text-xl font-black text-dark">Official Contact Details</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Customer Support Email</label>
              <input {...register('contactEmail')} className="input" type="email" />
            </div>
            <div>
              <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Support Phone</label>
              <input {...register('contactPhone')} className="input" />
            </div>
            <div>
              <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">WhatsApp Number</label>
              <input {...register('socialWhatsapp')} className="input" placeholder="234..." />
            </div>
          </div>
          <div>
            <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Headquarters Address</label>
            <input {...register('contactAddress')} className="input" />
          </div>
        </section>

        <section className="card space-y-6">
          <h2 className="text-xl font-black text-dark">Bank Transfer Details</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Bank Name</label>
              <input {...register('bankName')} className="input" />
            </div>
            <div>
              <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Account Name</label>
              <input {...register('bankAccountName')} className="input" />
            </div>
            <div>
              <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Account Number</label>
              <input {...register('bankAccountNumber')} className="input" />
            </div>
          </div>
        </section>

        <div className="fixed bottom-6 right-6 xl:right-12 z-50">
          <button 
            type="submit" 
            disabled={saving}
            className="btn green shadow-2xl px-10 py-5 text-base rounded-2xl flex items-center gap-3 transition-transform active:scale-95"
          >
            {saving ? <Loader2 className="animate-spin" size={20} /> : <Save size={20} />}
            Save All Settings
          </button>
        </div>
      </form>
    </div>
  );
}
