import { IKContext, IKUpload } from 'imagekitio-react';
import { useState } from 'react';
import { Loader2, UploadCloud, X } from 'lucide-react';

const publicKey = import.meta.env.VITE_IMAGEKIT_PUBLIC_KEY;
const urlEndpoint = import.meta.env.VITE_IMAGEKIT_URL_ENDPOINT;
const authenticationEndpoint = '/api/imagekit-auth';

interface ImageUploadProps {
  onUploadSuccess: (url: string) => void;
  label?: string;
  currentImage?: string;
  onRemove?: () => void;
  folder?: string;
  accept?: string;
}

export function ImageUpload({ 
  onUploadSuccess, 
  label = "Upload Image", 
  currentImage, 
  onRemove,
  folder = "products",
  accept = "image/*"
}: ImageUploadProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onError = (err: any) => {
    console.error("Upload Error:", err);
    setError("Upload failed. Please try again.");
    setIsUploading(false);
  };

  const onSuccess = (res: any) => {
    onUploadSuccess(res.url);
    setIsUploading(false);
    setError(null);
  };

  const onUploadStart = () => {
    setIsUploading(true);
    setError(null);
  };

  return (
    <div className="space-y-3">
      {label && <label className="block text-[11px] font-black uppercase tracking-widest text-[#667067]">{label}</label>}
      
      <IKContext 
        publicKey={publicKey} 
        urlEndpoint={urlEndpoint} 
        authenticationEndpoint={authenticationEndpoint}
      >
        <div className="relative">
          {currentImage ? (
            <div className="relative aspect-square w-full max-w-[200px] border-2 border-dashed border-[#dfe5df] rounded-2xl overflow-hidden group">
              <img src={currentImage} alt="Preview" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <button 
                  type="button"
                  onClick={onRemove}
                  className="bg-white/20 hover:bg-white/40 text-white p-2 rounded-full backdrop-blur-md transition-all"
                >
                  <X size={20} />
                </button>
              </div>
            </div>
          ) : (
            <div className={`
              relative aspect-square w-full max-w-[200px] border-2 border-dashed rounded-2xl flex flex-col items-center justify-center transition-all
              ${isUploading ? 'border-green bg-green/5' : 'border-[#dfe5df] bg-[#f8faf8] hover:border-green hover:bg-green/5'}
            `}>
              {isUploading ? (
                <div className="text-center p-4">
                  <Loader2 className="w-8 h-8 text-green animate-spin mx-auto mb-2" />
                  <p className="text-[10px] font-black uppercase tracking-tight text-green">Uploading...</p>
                </div>
              ) : (
                <label className="cursor-pointer text-center p-4 w-full h-full flex flex-col items-center justify-center">
                  <UploadCloud className="w-8 h-8 text-slate-300 mb-2" />
                  <p className="text-[10px] font-black uppercase tracking-tight text-slate-400">Click to upload</p>
                  <IKUpload
                    fileName={`upload_${Date.now()}`}
                    folder={folder}
                    useUniqueFileName={true}
                    onError={onError}
                    onSuccess={onSuccess}
                    onUploadStart={onUploadStart}
                    accept={accept}
                    className="hidden"
                  />
                </label>
              )}
            </div>
          )}
          
          {error && <p className="text-[10px] font-black text-danger mt-2 uppercase tracking-tight">{error}</p>}
        </div>
      </IKContext>
    </div>
  );
}
