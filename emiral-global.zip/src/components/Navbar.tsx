import { Link, useLocation } from 'react-router-dom';
import { ShoppingBag, Menu, X, Search } from 'lucide-react';
import { useState } from 'react';
import { useCart } from '../context/CartContext';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const { cart } = useCart();
  const location = useLocation();

  const navLinks = [
    { name: 'Home', href: '/' },
    { name: 'Products', href: '/products' },
    { name: 'Wellness', href: '/wellness' },
    { name: 'Business', href: '/opportunity' },
    { name: 'Community', href: '/community' },
    { name: 'Blog', href: '/blog' },
    { name: 'About', href: '/about' },
    { name: 'Contact', href: '/contact' },
  ];

  const cartCount = cart.reduce((acc, item) => acc + item.qty, 0);

  return (
    <>
      <div className="bg-[#14532d] text-white py-2 px-4 overflow-hidden whitespace-nowrap">
        <div className="flex animate-marquee gap-8 font-extrabold uppercase tracking-widest text-[9px]">
          <span>Discover Premium Herbal Wellness Products Created for Holistic Healing • </span>
          <span>Discover Premium Herbal Wellness Products Created for Holistic Healing • </span>
          <span>Discover Premium Herbal Wellness Products Created for Holistic Healing • </span>
          <span>Discover Premium Herbal Wellness Products Created for Holistic Healing • </span>
        </div>
      </div>
      <header className="site-header">
        <div className="container nav">
          {/* Zone 1: Brand */}
          <Link to="/" className="brand">
            <span className="brand-mark text-white">🌿</span>
            <span>
              <b className="text-[#14532d] font-black uppercase tracking-tight text-xl leading-none">EMIRAL</b>
              <small className="text-[#15803d] font-black tracking-[0.2em] -mt-1 uppercase">GLOBAL</small>
            </span>
          </Link>

          {/* Zone 2: Nav Links */}
          <nav className="menu hidden xl:flex">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.href}
                className={clsx(
                  "transition-colors",
                  location.pathname === link.href ? "text-[#15803d]" : "text-[#14532d]/70"
                )}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Zone 3: Actions */}
          <div className="actions">
            <Link to="/cart" className="cart-pill hidden md:flex items-center gap-2 rounded-full border-2 border-[#edf0ed] hover:border-green transition-colors px-4 py-2">
              <ShoppingBag size={18} className="text-[#15803d]" />
              <span className="font-black">({cartCount})</span>
            </Link>
            <button 
              className="mobile-toggle text-[#14532d]"
              onClick={() => setIsOpen(!isOpen)}
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="xl:hidden bg-white border-t border-line p-8 fixed inset-x-0 top-[110px] bottom-0 z-50 animate-in slide-in-from-top duration-300">
            <div className="grid grid-cols-1 gap-6">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.href}
                  className="py-2 text-2xl font-black uppercase tracking-tight text-[#14532d] hover:text-[#15803d]"
                  onClick={() => setIsOpen(false)}
                >
                  {link.name}
                </Link>
              ))}
              <div className="h-px bg-line my-4"></div>
              <Link
                to="/track-order"
                className="py-2 text-xl font-black uppercase tracking-tight text-[#14532d]/60"
                onClick={() => setIsOpen(false)}
              >
                Track Order
              </Link>
            </div>
          </div>
        )}
      </header>

      {/* Side Cart Tab - Fixed on right */}
      <Link 
        to="/cart" 
        className="fixed right-0 top-1/2 -translate-y-1/2 bg-[#14532d] text-white py-8 px-3 flex flex-col items-center gap-2 z-[100] rounded-l-2xl shadow-2xl hover:translate-x-[-4px] transition-transform"
      >
        <ShoppingBag size={24} />
        <span className="[writing-mode:vertical-lr] font-black uppercase tracking-widest text-[9px] mt-2">CART ({cartCount})</span>
      </Link>
    </>
  );
}
