import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useLocation, Outlet } from 'react-router-dom';
import { auth } from '../lib/firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { 
  LayoutDashboard, 
  Package, 
  ShoppingCart, 
  FileText, 
  MessageSquare, 
  Calendar, 
  HelpCircle, 
  Settings, 
  LogOut, 
  Globe 
} from 'lucide-react';

const ADMIN_EMAIL = "mgodswill306@gmail.com";

export function AdminLayout() {
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (!currentUser || currentUser.email !== ADMIN_EMAIL) {
        navigate('/admin/login');
      } else {
        setUser(currentUser);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [navigate]);

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/admin/login');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-soft">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green"></div>
      </div>
    );
  }

  const menuItems = [
    { name: 'Dashboard', href: '/admin', icon: LayoutDashboard },
    { name: 'Products', href: '/admin/products', icon: Package },
    { name: 'Orders', href: '/admin/orders', icon: ShoppingCart },
    { name: 'Content', href: '/admin/content', icon: Settings },
    { name: 'Blog', href: '/admin/blog', icon: FileText },
    { name: 'FAQ', href: '/admin/faq', icon: HelpCircle },
    { name: 'Community', href: '/admin/events', icon: Calendar },
    { name: 'Messages', href: '/admin/messages', icon: MessageSquare },
  ];

  return (
    <div className="admin-shell flex flex-col xl:flex-row min-h-screen bg-soft">
      {/* Sidebar */}
      <aside className="sidebar w-full xl:w-64 bg-dark text-white p-6 shrink-0">
        <div className="brand mb-10">
          <span className="brand-mark bg-white text-green">♛</span>
          <span>
            <b>EMIRAL</b>
            <small className="text-white/60">ADMIN PANEL</small>
          </span>
        </div>

        <nav className="flex flex-col gap-1">
          {menuItems.map((item) => (
            <Link
              key={item.name}
              to={item.href}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-bold transition-colors ${
                location.pathname === item.href ? 'bg-white/10 text-white' : 'text-white/60 hover:bg-white/5 hover:text-white'
              }`}
            >
              <item.icon size={18} />
              {item.name}
            </Link>
          ))}
          
          <div className="mt-8 pt-8 border-t border-white/10 flex flex-col gap-1">
            <Link 
              to="/" 
              className="flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-bold text-white/60 hover:bg-white/5 hover:text-white"
            >
              <Globe size={18} />
              View Website
            </Link>
            <button 
              onClick={handleLogout}
              className="flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-bold text-rose-400 hover:bg-rose-500/10 transition-colors w-full text-left"
            >
              <LogOut size={18} />
              Logout
            </button>
          </div>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-grow p-4 md:p-8 xl:p-12 overflow-x-hidden">
        <Outlet />
      </main>
    </div>
  );
}
