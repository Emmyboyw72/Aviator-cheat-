import React, { useEffect, useState } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { db, storage } from '../../lib/firebase';
import { doc, getDoc, setDoc, collection, addDoc, serverTimestamp, updateDoc } from 'firebase/firestore';
import { ArrowLeft, Save, Loader2 } from 'lucide-react';
import { ImageUpload } from '../../components/ImageUpload';

export function AdminProductForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [product, setProduct] = useState<any>(null);
  const { register, handleSubmit, reset, setValue, watch } = useForm();
  
  const thumbnail = watch('thumbnail');

  useEffect(() => {
    if (id) {
      setLoading(true);
      getDoc(doc(db, 'products', id)).then(snap => {
        if (snap.exists()) {
          const data = snap.data();
          setProduct({ id: snap.id, ...data });
          Object.keys(data).forEach(key => setValue(key, data[key]));
        }
      }).finally(() => setLoading(false));
    }
  }, [id, setValue]);

  const onSubmit = async (data: any) => {
    setLoading(true);
    try {
      const payload = {
        ...data,
        price: parseFloat(data.price),
        stock_quantity: parseInt(data.stock_quantity),
        published: !!data.published,
        featured: !!data.featured,
        updated_at: serverTimestamp()
      };

      if (id) {
        await updateDoc(doc(db, 'products', id), payload);
      } else {
        await addDoc(collection(db, 'products'), {
          ...payload,
          created_at: serverTimestamp(),
          currency: '₦'
        });
      }
      navigate('/admin/products');
    } catch (err) {
      alert('Failed to save product.');
    } finally {
      setLoading(false);
    }
  };

  if (loading && id) return <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green mx-auto mt-20"></div>;

  return (
    <div className="space-y-8 max-w-5xl">
      <div className="admin-head flex justify-between items-end">
        <div>
          <div className="eyebrow">Inventory</div>
          <h1 className="text-3xl font-black text-dark">{id ? 'Edit' : 'New'} Product</h1>
        </div>
        <Link to="/admin/products" className="btn outline flex items-center gap-2">
          <ArrowLeft size={18} /> Back
        </Link>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="card space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div>
              <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Product Name *</label>
              <input {...register('name', { required: true })} className="input" placeholder="e.g. Emiral Premium Tea" />
            </div>

            <div>
              <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Category</label>
              <select {...register('category')} className="input">
                {['WELLNESS', 'HERBAL', 'PERSONAL CARE', 'TEA & BEVERAGES'].map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">SKU</label>
                <input {...register('sku')} className="input" placeholder="EM-XXX" />
              </div>
              <div>
                <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Stock Quantity</label>
                <input type="number" {...register('stock_quantity')} className="input" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Price (₦)</label>
                <input type="number" step="0.01" {...register('price')} className="input" />
              </div>
              <div>
                <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Availability</label>
                <input {...register('availability')} className="input" placeholder="In Stock" />
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <ImageUpload 
              label="Product Image"
              currentImage={thumbnail}
              onUploadSuccess={(url) => setValue('thumbnail', url)}
              onRemove={() => setValue('thumbnail', '')}
              folder="products"
            />
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Short Description</label>
            <textarea {...register('short_description')} className="input" />
          </div>

          <div>
            <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Full Description</label>
            <textarea {...register('description')} className="input h-48" />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Ingredients</label>
            <textarea {...register('ingredients')} className="input h-32" />
          </div>
          <div>
            <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Usage Instructions</label>
            <textarea {...register('usage_instructions')} className="input h-32" />
          </div>
          <div>
            <label className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Product Information</label>
            <textarea {...register('product_information')} className="input h-32" />
          </div>
        </div>

        <div className="chips border-t border-line pt-8">
          <label className="pill flex items-center gap-3 cursor-pointer select-none">
            <input type="checkbox" {...register('featured')} className="w-4 h-4 accent-green" />
            Featured on Homepage
          </label>
          <label className="pill flex items-center gap-3 cursor-pointer select-none">
            <input type="checkbox" {...register('published')} className="w-4 h-4 accent-green" />
            Published / Visible to Public
          </label>
        </div>

        <div className="pt-8 border-t border-line flex justify-end">
          <button 
            type="submit" 
            disabled={loading || uploading}
            className="btn green px-12 py-4 text-base flex items-center gap-3"
          >
            {loading ? <Loader2 className="animate-spin" size={20} /> : <Save size={20} />}
            Save Product
          </button>
        </div>
      </form>
    </div>
  );
}
