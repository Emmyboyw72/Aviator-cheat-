import React, { useEffect, useState } from 'react';
import { db } from '../../lib/firebase';
import { collection, getDocs, updateDoc, doc, query, orderBy, serverTimestamp } from 'firebase/firestore';
import { ExternalLink, CheckCircle2, XCircle, Clock, Truck, Copy } from 'lucide-react';

export function AdminOrders() {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState<string | null>(null);

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const q = query(collection(db, 'orders'), orderBy('created_at', 'desc'));
      const snapshot = await getDocs(q);
      setOrders(snapshot.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleUpdate = async (id: string, field: string, value: string) => {
    setUpdating(id);
    try {
      await updateDoc(doc(db, 'orders', id), {
        [field]: value,
        updated_at: serverTimestamp()
      });
      fetchOrders();
    } catch (err) {
      alert('Failed to update order.');
    } finally {
      setUpdating(null);
    }
  };

  const money = (val: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0
    }).format(val);
  };

  if (loading) return <div className="animate-pulse space-y-4"><div className="h-96 bg-white rounded"></div></div>;

  const paymentOptions = ['WAITING_FOR_PAYMENT', 'PAYMENT_PROOF_SUBMITTED', 'PAYMENT_CONFIRMED', 'PAYMENT_REJECTED'];
  const statusOptions = ['Pending', 'Confirmed', 'Processing', 'Ready for Delivery', 'Delivered', 'Cancelled'];

  return (
    <div className="space-y-10">
      <div className="admin-head">
        <div>
          <div className="eyebrow">Sales</div>
          <h1 className="text-3xl font-black text-dark">Orders</h1>
        </div>
      </div>

      <div className="table-wrap rounded-xl bg-white shadow-sm border border-line">
        <table>
          <thead>
            <tr>
              <th>Order / Date</th>
              <th>Customer</th>
              <th>Total / Receipt</th>
              <th>Payment Status</th>
              <th>Order Status</th>
              <th>Update</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id} className={updating === o.id ? 'opacity-50' : ''}>
                <td>
                  <div className="flex items-center gap-2">
                    <b className="text-dark tracking-wider">{o.order_number}</b>
                    <button 
                      onClick={() => {
                        navigator.clipboard.writeText(o.order_number);
                        alert('Order number copied!');
                      }}
                      className="p-1 rounded bg-slate-100 text-slate-400 hover:text-green"
                    >
                      <Copy size={12} />
                    </button>
                  </div>
                  <div className="text-[10px] text-muted font-bold mt-1">
                    {o.created_at?.toDate().toLocaleString('en-GB')}
                  </div>
                </td>
                <td>
                  <div className="font-bold text-dark">{o.customer_name}</div>
                  <div className="text-xs text-muted">{o.customer_email}</div>
                  <div className="text-xs text-muted">{o.customer_phone}</div>
                </td>
                <td>
                  <div className="font-black text-dark">{money(o.total)}</div>
                  {o.payment_receipt_url ? (
                    <a 
                      href={o.payment_receipt_url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-[10px] font-black text-green uppercase tracking-widest flex items-center gap-1 mt-1 hover:underline"
                    >
                      View Receipt <ExternalLink size={10} />
                    </a>
                  ) : (
                    <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest block mt-1">No Receipt</span>
                  )}
                </td>
                <td>
                   <select 
                    value={o.payment_status}
                    onChange={(e) => handleUpdate(o.id, 'payment_status', e.target.value)}
                    className={`status outline-none cursor-pointer ${o.payment_status === 'PAYMENT_CONFIRMED' ? 'green' : 'orange'}`}
                  >
                    {paymentOptions.map(opt => (
                      <option key={opt} value={opt}>{opt.replace(/_/g, ' ')}</option>
                    ))}
                  </select>
                </td>
                <td>
                  <select 
                    value={o.order_status}
                    onChange={(e) => handleUpdate(o.id, 'order_status', e.target.value)}
                    className={`status outline-none cursor-pointer ${o.order_status === 'Delivered' ? 'green' : 'orange'}`}
                  >
                    {statusOptions.map(opt => (
                      <option key={opt} value={opt}>{opt}</option>
                    ))}
                  </select>
                </td>
                <td>
                  <button 
                    disabled={updating === o.id}
                    onClick={() => fetchOrders()}
                    className="btn outline p-2 rounded-lg"
                  >
                    Refresh
                  </button>
                </td>
              </tr>
            ))}
            {orders.length === 0 && (
              <tr>
                <td colSpan={6} className="text-center py-20 text-muted font-bold italic">No orders found.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
